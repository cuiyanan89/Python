from django.contrib import admin
from blog.models import Customer,Types,Foods

admin.site.register(Customer)
admin.site.register(Types)
admin.site.register(Foods)
